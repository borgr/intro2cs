#############################################################
# FILE : Hello.py
# WRITER : Leshem Choshen + borgr + 305385338
# EXERCISE : intro2cs ex0 200132014
# DESCRIPTION:
# A simple program that prints "Hello World" to the standard
# output (screen).
#############################################################
print("Hello World")
