#############################################################
# FILE : AlignDNA.py
# WRITER : Leshem Choshen + borgr + 305385338
# EXERCISE : intro2cs ex4 200132014
# DESCRIPTION:DNA****
# 
#############################################################
#!/usr/bin/env python3

from PIL import Image


def change(image, func):
    print(image.size, image.getpixel((0,0)))
    for row in range(image.size[0]):
        for col in range(image.size[1]):
            putty = func(image.getpixel((row,col)))
            image.putpixel((row,col), tuple(putty))
            
class ExtendedImage(object):        
    def __init__(self,img):
        self._img=img
    def __getattr__(self,key):
        if key == '_img':
            raise AttributeError()
        return getattr(self._img,key)

    def adjust_brightness(self, levels):
        L = levels
        change(self, lambda pixel:(b*L//256*255//(L-1) for b in pixel))
        #modifies self, returns None

    def expand_range(self):
        mn = [255 for rgb in self.getpixel((0,0))]
        mx = [0 for rgc in  self.getpixel((0,0))]
        for row in range(self.size[0]):
            for col in range(self.size[1]):
                check = self.getpixel((row,col))
                for rgb in range(3):
                    if mn[rgb] > check[rgb]:
                        mn[rgb] = check[rgb]
                    if mx[rgb] > check[rgb]:
                        mx[rgb] = check[rgb]
        if mn != mx:
            change(self, lambda pixel:((b-mn[rgb])*(255/(mx[rgb]-mn[rgb])) for b, rgb in enumerate(pixel)))
        #modifies self, returns None

    def range_reduction(self, factor):
        new = ExtendedImage(self.copy())
        change(new, lambda pixel: (b//factor*factor for b in pixel))
        return new
        #returns new ExtendedImage, self not modified

    def waterfall(self):
        new = ExtendedImage(self.copy())
        for row in range(1, new.size[0]):
            for col in range(1, new.size[1]):
                putty = new.getpixel((row,col))
                up = self.getpixel((row,col-1))
                putty = ((b-a)%255 for a,b in zip(up,putty))
                new.putpixel((row,col), tuple(putty))
        return new
        #returns new ExtendedImage, self not modified

    def waterfall_restore(self):
        new = ExtendedImage(self.copy())
        for row in range(1, new.size[0]):
            for col in range(1, new.size[1]):
                putty = new.getpixel((row,col))
                up = new.getpixel((row,col-1))
                putty = ((a+b)%255 for a,b in zip(up,putty))
                new.putpixel((row,col), tuple(putty))
        return new
        #returns new ExtendedImage, self not modified

    def wavelet(self):
        '''Your code here'''
        #returns new ExtendedImage, self not modified

    def wavelet_restore(self):
        '''Your code here'''
        #returns new ExtendedImage, self not modified
