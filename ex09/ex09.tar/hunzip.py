#!/usr/bin/env python3
'''
usage: hunzip.py [-h] [-o OUTFILE] [-s SUFFIX] [-S OUTSUFFIX] [-f] infile

Decompress files using the hzlib module.

positional arguments:
  infile

optional arguments:
  -h, --help            show this help message and exit
  -o OUTFILE, --outfile OUTFILE
                        Name of output file
  -s SUFFIX, --suffix SUFFIX
                        Default suffix to remove instead of .hz
  -S OUTSUFFIX, --outsuffix OUTSUFFIX
                        Default suffix to add if instead of .out
  -f, --force           Force decompression and overwrite output file if it
                        exists
'''
from hzlib import *

DEFAULT_IN_EXTENSION = '.hz'
DEFAULT_OUT_EXTENSION = '.out'

def main():
    import argparse
    parser = argparse.ArgumentParser(
        description='Decompress files using the hzlib module.')
##    parser.add_argument("infile")
    parser.add_argument("-o", "--outfile", type=str, default=None, 
                        help='Name of output file')
    parser.add_argument("-s", "--suffix", type=str,
                        default=DEFAULT_IN_EXTENSION,
                        help=('Default suffix to remove instead of ' +
                              DEFAULT_IN_EXTENSION))
    parser.add_argument("-S", "--outsuffix", type=str,
                        default=DEFAULT_OUT_EXTENSION,
                        help=('Default suffix to add if instead of ' +
                              DEFAULT_OUT_EXTENSION))
    parser.add_argument("-f", "--force", action='store_true',
                        help=('Force decompression and overwrite output ' +
                              'file if it exists'))
    args = parser.parse_args()

    #Your code goes here and in the other functions you should write...
        # If you do not want to force check if the file exists
        #how?!
    args.infile = "ziptest"
    args.suffix = ".hz"
    args.outfile = "unziptest"
    args.outsuffix = ".unz"
    counter = 0
    # open files
    with open(args.outfile + args.outsuffix, "w") as outfile:
        with open(args.infile+args.suffix) as infile:
            data = infile.read()
            print("data", data, "MAGIC",MAGIC, "start", data[:len(str(MAGIC))]==str(MAGIC))
            print(data[:len(str(MAGIC))])
            print(len(str(MAGIC)))
            #check if the file is compressed
            if data[:len(str(MAGIC))] == str(MAGIC):
                print("magic")
                data = data[len(str(MAGIC)):]

                #check the level of compression
                levels = int(data[0])
                data = data[1:]
                print("levels", levels)

                # decompress
                for level in range(levels):
                    counter +=1
                    data = list(data)
                    print("preunpad",data, counter)
                    data = unpad((int(bit) for bit in data)) #each time or only at the first time?
                    data = list(data)
                    print("unpaded", data)
                    splitted = split(data)
                    print("splitted", list(splitted[0]),"splitted1", list(splitted[1]),"data", data)
                    data = list(decompress(splitted[0], splitted[1]))
                    print("decompressed", data)
##                    data = data[:data.rindex(".")] # delete the names will that work? where are the names stored?
                data = unpad(data) # necessary?
            outfile.write(str(data))
                
            


if __name__ == '__main__':
    main()
